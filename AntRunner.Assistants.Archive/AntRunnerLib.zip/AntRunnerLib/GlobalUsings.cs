// Global using directives

global using System.Diagnostics;
global using System.Text.Json;
global using System.Text.Json.Serialization;
global using OpenAI.Extensions;
global using OpenAI.Interfaces;
global using OpenAI.ObjectModels.RequestModels;
global using OpenAI.ObjectModels.ResponseModels;
global using OpenAI.ObjectModels.SharedModels;
global using static AntRunnerLib.ClientUtility;
global using static System.Diagnostics.Trace;