﻿namespace OpenAI.ObjectModels.ResponseModels.VectorStoreResponseModels;

public record VectorStoreListObjectResponse : DataWithPagingBaseResponse<List<VectorStoreObjectResponse>>
{
}