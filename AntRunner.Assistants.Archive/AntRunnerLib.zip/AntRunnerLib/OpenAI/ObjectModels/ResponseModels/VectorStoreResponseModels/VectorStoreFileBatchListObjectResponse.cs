﻿namespace OpenAI.ObjectModels.ResponseModels.VectorStoreResponseModels;

public record VectorStoreFileBatchListObjectResponse : DataWithPagingBaseResponse<List<VectorStoreFileBatchObject>>
{
}