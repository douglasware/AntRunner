This is a cut down fork of https://github.com/betalgo/openai with a number of bug fixes to Azure Endpoints and JSON serialization, esp around tool definitions and function parameters.

The original code was written by Betalgo and is licensed under the MIT license. This code is also licensed under the MIT license.