$scriptdir = $PSScriptRoot
Import-Module $scriptdir\PowerShellModule.psm1